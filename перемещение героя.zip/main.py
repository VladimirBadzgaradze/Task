import os
import sys
import pygame


class Tile(pygame.sprite.Sprite):
    def __init__(self, app, tile_type, pos_x, pos_y):
        super().__init__(app.tiles_group, app.all_sprites)
        self.image = app.tile_images[tile_type]
        self.rect = self.image.get_rect()

        self.rect.x = pos_x
        self.rect.y = pos_y


class Hero(pygame.sprite.Sprite):
    def __init__(self, app, pos):
        super().__init__(app.all_sprites)
        self.app = app

        self.image = app.load_image("mar.png")
        self.rect = self.image.get_rect()
        # вычисляем маску для эффективного сравнения
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = pos[0]
        self.rect.y = pos[1]

        self.speed_x, self.speed_y = 5, 5

    def update(self, w, a, s, d):
        velx = 0
        if a:
            self.rect.x -= self.speed_x
            velx -= self.speed_x
        if d:
            self.rect.x += self.speed_x
            velx += self.speed_x

        self.collide(velx, 0, self.app.box_sprites)

        vely = 0
        if s:
            self.rect.y += self.speed_y
            vely += self.speed_y
        if w:
            self.rect.y -= self.speed_y
            vely -= self.speed_y

        self.collide(0, vely, self.app.box_sprites)

    def collide(self, velx, vely, obg):
        collision = pygame.sprite.spritecollide(self, obg, False)
        for block in collision:
            if velx > 0:
                self.rect.right = block.rect.left
            if velx < 0:
                self.rect.left = block.rect.right

            if vely > 0:
                self.rect.bottom = block.rect.top
            if vely < 0:
                self.rect.top = block.rect.bottom

class App:
    def __init__(self):
        pygame.init()
        self.width, self.height = 500, 500
        self.clock = pygame.time.Clock()
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption('Mario')
        self.fps = 50

        self.rect = pygame.Rect(0, 0, 500, 500)

        self.all_sprites = pygame.sprite.Group()
        self.tiles_group = pygame.sprite.Group()
        self.box_sprites = pygame.sprite.Group()
        self.player_group = pygame.sprite.Group()

        self.tile_images = {
            'wall': self.load_image('box.png'),
            'empty': self.load_image('grass.png')
        }
        self.player_image = self.load_image('mar.png')

        self.tile_width = self.tile_height = 50

    def terminate(self):
        pygame.quit()
        sys.exit()

    def load_level(self, filename):
        filename = "data/" + filename
        # читаем уровень, убирая символы перевода строки
        with open(filename, 'r') as mapFile:
            level_map = [line.strip() for line in mapFile]

        # и подсчитываем максимальную длину
        max_width = max(map(len, level_map))

        # дополняем каждую строку пустыми клетками ('.')
        return list(map(lambda x: x.ljust(max_width, '.'), level_map))

    def start_screen(self):
        intro_text = ["ЗАСТАВКА", "",
                      "Правила игры",
                      "Если в правилах несколько строк,",
                      "приходится выводить их построчно"]

        fon = pygame.transform.scale(self.load_image('fon.jpg'), (self.width, self.height))
        self.screen.blit(fon, (0, 0))
        font = pygame.font.Font(None, 30)
        text_coord = 50
        for line in intro_text:
            string_rendered = font.render(line, 1, pygame.Color('black'))
            intro_rect = string_rendered.get_rect()
            text_coord += 10
            intro_rect.top = text_coord
            intro_rect.x = 10
            text_coord += intro_rect.height
            self.screen.blit(string_rendered, intro_rect)

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.terminate()
                elif event.type == pygame.KEYDOWN or \
                        event.type == pygame.MOUSEBUTTONDOWN:
                    self.game_over = 0
                    return  # начинаем игру
            pygame.display.flip()
            self.clock.tick(self.fps)

    def load_image(self, name, colorkey=None):
        fullname = os.path.join('data', name)
        # если файл не существует, то выходим
        if not os.path.isfile(fullname):
            print(f"Файл с изображением '{fullname}' не найден")
            sys.exit()
        image = pygame.image.load(fullname)
        if colorkey is not None:
            image = image.convert()
            if colorkey == -1:
                colorkey = image.get_at((0, 0))
            image.set_colorkey(colorkey)
        else:
            image = image.convert_alpha()
        return image

    def generate_level(self, level):
        new_player, x, y = None, None, None

        xx, yy = 0, 0
        for y in range(len(level)):
            xx = 0
            for x in range(len(level[y])):
                print(xx, yy)
                if level[y][x] == '.':
                    Tile(self, 'empty', xx, yy)
                elif level[y][x] == '#':
                    block = Tile(self, 'wall', xx, yy)
                    self.box_sprites.add(block)
                elif level[y][x] == '@':
                    Tile(self, 'empty', xx, yy)
                    new_player = Hero(self, (xx, yy))

                xx += self.tile_width
            yy += self.tile_height

        x, y = xx // self.tile_width, yy // self.tile_height

        # вернем игрока, а также размер поля в клетках
        return new_player, x, y

    def run_game(self):
        player, level_x, level_y = self.generate_level(self.load_level('map.txt'))
        self.hero = player

        self.game_over = 0
        run = True
        while run:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.terminate()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    self.game_over += 1
            if self.game_over == 1:
                self.start_screen()
                if self.game_over == 1:
                    run = False

            # update
            mouse_press = pygame.key.get_pressed()

            self.hero.update(mouse_press[pygame.K_w], mouse_press[pygame.K_a], mouse_press[pygame.K_s], mouse_press[pygame.K_d])

            # render
            self.screen.fill(pygame.Color('blue'))
            self.all_sprites.draw(self.screen)

            self.screen.blit(self.hero.image, (self.hero.rect.x, self.hero.rect.y))

            pygame.display.flip()
            self.clock.tick(self.fps)


if __name__ == '__main__':
    app = App()
    app.start_screen()
    app.run_game()